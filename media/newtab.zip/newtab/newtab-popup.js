function showrick() {
	document.getElementById("switch").style.display = "none";
	document.getElementById("hint").style.display = "block";
	document.getElementById("hint").play();
	document.documentElement.requestFullscreen();
}

document.addEventListener("DOMContentLoaded",
	function () {
		document.getElementById("rickrollswitch").addEventListener("click", showrick);
	}
);