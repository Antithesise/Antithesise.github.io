var particles = [];

// Global variables to store our browser's window size
var browserWidth;
var browserHeight;

// Specify the number of particles you want visible
var numberOfparticles = 100;

// Flag to reset the position of the particles
var resetPosition = false;

// Handle accessibility
var enableAnimations = false;
var reduceMotionQuery = matchMedia("(prefers-reduced-motion)");

// Handle animation accessibility preferences 
function setAccessibilityState() {
	if (reduceMotionQuery.matches) {
		enableAnimations = false;
	} else { 
		enableAnimations = true;
	}
}
setAccessibilityState();

reduceMotionQuery.addListener(setAccessibilityState);

//
// It all starts here...
//
function setup() {
	if (enableAnimations) {
		window.addEventListener("DOMContentLoaded", generateparticles, false);
		window.addEventListener("resize", setResetFlag, false);
	}
}
setup();

//
// Constructor for our particle object
//
function particle(element, speed, xPos, yPos) {
	// set initial particle properties
	this.element = element;
	this.speed = speed;
	this.xPos = xPos;
	this.yPos = yPos;
	this.scale = 1;

	// declare variables used for particle's motion
	this.counter = 0;
	this.sign = Math.random() < 0.5 ? 1 : -1;

	// setting an initial opacity and size for our particle
	this.element.style.opacity = (.1 + Math.random()) / 3;
}

//
// The function responsible for actually moving our particle
//
particle.prototype.update = function () {
	// using some trigonometry to determine our x and y position
	this.counter += this.speed / 5000;
	this.xPos += this.sign * this.speed * Math.cos(this.counter) / 40;
	this.yPos += Math.sin(this.counter) / 40 + this.speed / 30;
	this.scale = .5 + Math.abs(10 * Math.cos(this.counter) / 20);

	// setting our particle's position
	setTransform(Math.round(this.xPos), Math.round(this.yPos), this.scale, this.element);

	// if particle goes below the browser window, move it back to the top
	if (this.yPos > browserHeight) {
		this.yPos = -50;
	}
}

//
// A performant way to set your particle's position and size
//
function setTransform(xPos, yPos, scale, el) {
	el.style.transform = `translate3d(${xPos}px, ${yPos}px, 0) scale(${scale}, ${scale})`;
}

//
// The function responsible for creating the particle
//
function generateparticles() {

	// get our particle element from the DOM and store it
	var originalparticle = document.querySelector(".particle");

	// access our particle element's parent container
	var particleContainer = originalparticle.parentNode;
	particleContainer.style.display = "block";

	// get our browser's size
	browserWidth = document.documentElement.clientWidth;
	browserHeight = document.documentElement.clientHeight;

	// create each individual particle
	for (var i = 0; i < numberOfparticles; i++) {

		// clone our original particle and add it to particleContainer
		var particleClone = originalparticle.cloneNode(true);
		particleContainer.appendChild(particleClone);

		// set our particle's initial position and related properties
		var initialXPos = getPosition(50, browserWidth);
		var initialYPos = getPosition(50, browserHeight);
		var speed = 5 + Math.random() * (40 - (30 * (document.getElementsByTagName("html")[0].dataset.theme == "hallows")));

		// create our particle object
		var particleObject = new particle(particleClone,
			speed,
			initialXPos,
			initialYPos);
		particles.push(particleObject);
	}

	// remove the original particle because we no longer need it visible
	particleContainer.removeChild(originalparticle);

	moveparticles();
}

//
// Responsible for moving each particle by calling its update function
//
function moveparticles() {

	if (enableAnimations) {
		for (var i = 0; i < particles.length; i++) {
			var particle = particles[i];
			particle.update();
		}			
	}

	// Reset the position of all the particles to a new value
	if (resetPosition) {
		browserWidth = document.documentElement.clientWidth;
		browserHeight = document.documentElement.clientHeight;

		for (var i = 0; i < particles.length; i++) {
			var particle = particles[i];

			particle.xPos = getPosition(50, browserWidth);
			particle.yPos = getPosition(50, browserHeight);
		}

		resetPosition = false;
	}

	requestAnimationFrame(moveparticles);
}

//
// This function returns a number between (maximum - offset) and (maximum + offset)
//
function getPosition(offset, size) {
	return Math.round(-1 * offset + Math.random() * (size + 2 * offset));
}

//
// Trigger a reset of all the particles' positions
//
function setResetFlag(e) {
	resetPosition = true;
}