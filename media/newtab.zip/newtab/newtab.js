var shift = false;
var caps = false;
var ready = false;

if (typeof(localStorage.text) != undefined && localStorage.text != undefined) {
	document.getElementById("text").innerHTML = localStorage.text;
} else {
	localStorage.text = document.getElementById("text").innerHTML;
}

if (typeof(localStorage.theme) != undefined && localStorage.theme != undefined) {
	document.getElementsByTagName("html")[0].dataset.theme = localStorage.theme;
} else {
	localStorage.theme = "light";
	document.getElementsByTagName("html")[0].dataset.theme = "light";
}

window.languagePluginUrl = "https://pyodide-cdn2.iodide.io/v0.15.0/full/";

document.getElementById("setfont").value = parseFloat(window.getComputedStyle(document.getElementById('text'), null).getPropertyValue('font-size'));
automenu();
setTimeout(automenu, 2500);

document.addEventListener("DOMContentLoaded",
	function () {
		document.getElementById("show").addEventListener("click", automenu);
		document.getElementById("show").addEventListener("mouseover", showmenu);
		document.getElementById("menubox").addEventListener("mouseleave", hidemenu);

		document.getElementById("menu-link-light").addEventListener("click", function () {
			document.getElementsByTagName("html")[0].dataset.theme = "light";
			localStorage.theme = "light";
		});
		document.getElementById("menu-link-dark").addEventListener("click", function () {
			document.getElementsByTagName("html")[0].dataset.theme = "dark";
			localStorage.theme = "dark";
		});
		document.getElementById("menu-link-hallows").addEventListener("click", function () {
			document.getElementsByTagName("html")[0].dataset.theme = "hallows";
			localStorage.theme = "hallows";
		});
		document.getElementById("menu-link-xmas").addEventListener("click", function () {
			document.getElementsByTagName("html")[0].dataset.theme = "xmas";
			localStorage.theme = "xmas";
		});

		window.addEventListener("mousemove", function (event) {document.getElementById("frost").style.left = `${event.clientX}px`; document.getElementById("frost").style.top = `${event.clientY}px`;});

		document.getElementById("text").addEventListener("keyup", function () {localStorage.text = document.getElementById("text").innerHTML;});
		document.getElementById("text").addEventListener("mouseup", function () {localStorage.text = document.getElementById("text").innerHTML;});
		document.getElementById("text").addEventListener("mousedown", function () {localStorage.text = document.getElementById("text").innerHTML;});
		document.getElementById("text").addEventListener("keydown", function () {localStorage.text = document.getElementById("text").innerHTML;});
		
		document.getElementById("bigger").addEventListener("click", function () {changeFSize(1);})
		document.getElementById("setfont").addEventListener("keydown", function (k) {if (k.keyCode == 13) {setFSize(document.getElementById("setfont").value);}});
		document.getElementById("setfont").addEventListener("focusout", function () {setFSize(document.getElementById("setfont").value);});
		document.getElementById("smaller").addEventListener("click", function () {changeFSize(-1);})
		document.getElementById("clear").addEventListener("click", function () {document.getElementById("text").innerHTML = ""; localStorage.text = "";});
		document.getElementById("default").addEventListener("click", function () {document.getElementById("text").innerHTML = "Keys that don't do anything:\n	- ctrl\n	- alt\n	- up\n	- left\n	- down\n	- right\n\n*note that tab is equal to 4 spaces.<br><br>You can use a keyboard or the one on screen.<br>You can also move the caret by clicking."; localStorage.text = document.getElementById("text").innerHTML; setFSize(12)});
		document.getElementById("save").addEventListener("click", save);
		document.getElementById("time").addEventListener("click", updateTime);
		document.getElementById("calculate").addEventListener("click", function () {document.getElementById("calculator").value = mexp.eval(document.getElementById("calculator").value);});
		document.getElementById("settings").addEventListener("click", function () {document.getElementById("settingsWindow").style.display = "block"; document.getElementById("keyboard").style.display = "none"; document.getElementById("menu-bar").style.display = "none"; document.getElementById("fkeys").style.display = "none"; document.getElementById("textbox").style.display = "none"; document.getElementById("hint").play(); document.getElementById("hint").requestFullscreen()});
		
		document.getElementById("tittle").addEventListener("click", function () {add("`", "~");});
		document.getElementById("exclamation").addEventListener("click", function () {add("1", "!");});
		document.getElementById("at").addEventListener("click", function () {add("2", "@");});
		document.getElementById("hashtag").addEventListener("click", function () {add("3", "#");});
		document.getElementById("dollars").addEventListener("click", function () {add("4", "$");});
		document.getElementById("percent").addEventListener("click", function () {add("5", "%");});
		document.getElementById("hat").addEventListener("click", function () {add("6", "^");});
		document.getElementById("and").addEventListener("click", function () {add("7", "&");});
		document.getElementById("asterix").addEventListener("click", function () {add("8", "*");});
		document.getElementById("openingparanethesis").addEventListener("click", function () {add("9", "(");});
		document.getElementById("closingparanethesis").addEventListener("click", function () {add("0", ")");});
		document.getElementById("underscore").addEventListener("click", function () {add("-", "_");});
		document.getElementById("plus").addEventListener("click", function () {add("=", "+");});
		document.getElementById("backspace").addEventListener("click", function () {sub(1);});
		document.getElementById("tab").addEventListener("click", function () {add("\t", "\t");});
		document.getElementById("q").addEventListener("click", function () {add("q", "Q");});
		document.getElementById("w").addEventListener("click", function () {add("w", "W");});
		document.getElementById("e").addEventListener("click", function () {add("e", "E");});
		document.getElementById("r").addEventListener("click", function () {add("r", "R");});
		document.getElementById("t").addEventListener("click", function () {add("t", "T");});
		document.getElementById("y").addEventListener("click", function () {add("y", "Y");});
		document.getElementById("u").addEventListener("click", function () {add("u", "U");});
		document.getElementById("i").addEventListener("click", function () {add("i", "I");});
		document.getElementById("o").addEventListener("click", function () {add("o", "O");});
		document.getElementById("p").addEventListener("click", function () {add("p", "P");});
		document.getElementById("openingcurly").addEventListener("click", function () {add("[", "{");});
		document.getElementById("closingcurly").addEventListener("click", function () {add("]", "}");});
		document.getElementById("pipe").addEventListener("click", function () {add("\\", "|");});
		document.getElementById("caps").addEventListener("click", capslock);
		document.getElementById("a").addEventListener("click", function () {add("a", "A");});
		document.getElementById("s").addEventListener("click", function () {add("s", "S");});
		document.getElementById("d").addEventListener("click", function () {add("d", "D");});
		document.getElementById("f").addEventListener("click", function () {add("f", "F");});
		document.getElementById("g").addEventListener("click", function () {add("g", "G");});
		document.getElementById("h").addEventListener("click", function () {add("h", "H");});
		document.getElementById("j").addEventListener("click", function () {add("j", "J");});
		document.getElementById("k").addEventListener("click", function () {add("k", "K");});
		document.getElementById("l").addEventListener("click", function () {add("l", "L");});
		document.getElementById("colon").addEventListener("click", function () {add(";", ":");});
		document.getElementById("doublequote").addEventListener("click", function () {add("\'", "\"");});
		document.getElementById("enter").addEventListener("click", function () {add("\n", "\n");});
		document.getElementById("shift").addEventListener("mousedown", function () {shift=true;});
		document.getElementById("shift").addEventListener("mouseup", function () {shift=false;});
		document.getElementById("z").addEventListener("click", function () {add("z", "Z");});
		document.getElementById("x").addEventListener("click", function () {add("x", "X");});
		document.getElementById("c").addEventListener("click", function () {add("c", "C");});
		document.getElementById("v").addEventListener("click", function () {add("v", "V");});
		document.getElementById("b").addEventListener("click", function () {add("b", "B");});
		document.getElementById("n").addEventListener("click", function () {add("n", "N");});
		document.getElementById("m").addEventListener("click", function () {add("m", "M");});
		document.getElementById("less").addEventListener("click", function () {add(",", "<");});
		document.getElementById("more").addEventListener("click", function () {add(".", ">");});
		document.getElementById("question").addEventListener("click", function () {add("/", "?");});
		document.getElementById("ctrl").addEventListener("click", function () {null;});
		document.getElementById("alt").addEventListener("click", function () {null;});
		document.getElementById("space").addEventListener("click", function () {add(" ", " ");});
		document.getElementById("uparrow").addEventListener("click", function () {null;});
		document.getElementById("leftarrow").addEventListener("click", function () {null;});
		document.getElementById("downarrow").addEventListener("click", function () {null;});
		document.getElementById("rightarrow").addEventListener("click", function () {null;});

		for (var i = 0 ; i < document.body.getElementsByTagName("*").length; i++) {
			document.body.getElementsByTagName("*")[i].addEventListener("keydown" , function (k) {if (k.keyCode == 9) {k.preventDefault();}});
			document.getElementsByTagName('*')[i].ondragstart = function() {return false;};
		};
	}
);

function showmenu() {
	if (!ready) {
		ready = !ready;
		if (document.getElementById("menu").style.transform != "translateX(0px)") {
			document.getElementById("show").style.borderRadius = "100% 0 0 100%";
			setTimeout(function () {
				document.getElementById("menu").style.transform = "translateX(0px)";
				setTimeout(function () {
					ready = !ready;
				}, 500);
			}, 500);
		} else {
			ready = !ready;
		}
	}
}

function hidemenu() {
	if (!ready) {
		ready = !ready;
		if (document.getElementById("menu").style.transform == "translateX(0px)") {
			document.getElementById("menu").style.transform = "translateX(-200px)";
			setTimeout(function () {
				document.getElementById("show").style.borderRadius = "100%";
				setTimeout(function () {
					ready = !ready;
				}, 800);
			}, 500);
		} else {
			ready = !ready;
		}
	}
}

function automenu() {
	if (document.getElementById("menu").style.transform == "translateX(0px)") {
		hidemenu();
	} else {
		showmenu();
	}
}

function save() {
	var element = document.createElement("a");
	element.href = "data:text/plain;charset=utf-8," + encodeURIComponent(localStorage.text);
	element.download = "new-tab-text.txt";
	element.style.display = "none";
	document.body.appendChild(element);
	element.click();
	document.body.removeChild(element);
}

function updateTime() {
	date = new Date();
	document.getElementById("time").innerHTML = (("0" + date.getHours()).slice(-2)) + ":" + (("0" + date.getMinutes()).slice(-2)) + ":" + (("0" + date.getSeconds()).slice(-2)) + " " + (("0" + date.getDate()).slice(-2)) + "/" + (("0" + (date.getMonth()+1)).slice(-2)) + "/" + (date.getFullYear());
	setTimeout(function () {
		document.getElementById("time").innerHTML = "time";
	}, 3000);
}

function changeFSize(value) {
	document.getElementById('text').style.fontSize = (parseFloat(window.getComputedStyle(document.getElementById('text'), null).getPropertyValue('font-size')) + value) + 'px';
	document.getElementById("setfont").value = parseFloat(window.getComputedStyle(document.getElementById('text'), null).getPropertyValue('font-size'));
}

function setFSize(value) {
    document.getElementById('text').style.fontSize = value + 'px';
}

function add(key1, key2) {
	if (shift || caps) {
		document.getElementById("text").innerHTML += String(key2);
	} else {
		document.getElementById("text").innerHTML += String(key1);
	}
	localStorage.text = document.getElementById("text").innerHTML;
}

function sub(value) {
	document.getElementById("text").innerHTML = document.getElementById("text").innerHTML.slice(0, document.getElementById("text").innerHTML.length - value);
	localStorage.text = document.getElementById("text").innerHTML;
}

function capslock(change=true) {
	if (change) {
		caps = ! caps;
	}
	if (caps) {
		document.getElementById("indicator").style.color = "rgb(0, 255, 0)";
	} else {
		if (localStorage.theme == "light") {
			document.getElementById("indicator").style.color = "black";
		} else {
			document.getElementById("indicator").style.color = "white";
		}
	}
}